package com.example.demo.other;

import org.springframework.stereotype.Component;

@Component
public class FileDto {

    public String fileName;
    public byte[] file;

    public String getFileName() {
        return fileName;
    }

    public void setFileName(String fileName) {
        this.fileName = fileName;
    }

    public byte[] getFile() {
        return file;
    }

    public void setFile(byte[] file) {
        this.file = file;
    }
}
