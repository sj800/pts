package com.example.demo.other;

public class FileErrors {

    public static final String INVALID_FILE="File contains invalid characters.";
    public static final String FILE_NOT_STORED="File cannot be stored.";
    public static final String FILE_NOT_FOUND="File does not exist.";



}
